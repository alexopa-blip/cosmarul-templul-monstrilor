# COȘMARUL: TEMPLUL MONȘTRILOR — proiect Android de test

Acest proiect împachetează prototipul HTML5 într-o aplicație Android folosind Capacitor.
Fișierul jocului este `www/index.html` și a fost păstrat din fișierul furnizat.

## Ce poate produce
- Workflow-ul GitHub Actions construiește un **APK debug** pentru instalare și testare.
- Acesta NU este încă un AAB semnat pentru Google Play.
- Reclamele NU sunt integrate sau active.
- Nu este o versiune finală QA și trebuie testată pe dispozitiv.

## Construire doar cu telefonul, prin GitHub Actions

1. Creează sau conectează-te la un cont GitHub.
2. Creează un repository nou, de exemplu `cosmarul-templul-monstrilor`.
3. Încarcă în repository toate fișierele și folderele din acest proiect, inclusiv folderul ascuns `.github`.
   Structura trebuie să păstreze:
   - `www/index.html`
   - `package.json`
   - `capacitor.config.json`
   - `.github/workflows/android-apk.yml`
4. Deschide repository-ul în GitHub → **Actions**.
5. Dacă GitHub cere, apasă **I understand my workflows, go ahead and enable them**.
6. Alege workflow-ul **Build Android test APK** → **Run workflow**.
7. Așteaptă să termine cu succes. Deschide rularea, apoi descarcă artifact-ul `cosmarul-test-apk`.
8. Extrage artifact-ul ZIP și instalează `app-debug.apk` pe telefon. Android poate cere să permiți instalarea din sursa folosită.

## Important pentru Google Play
Google Play cere un Android App Bundle (`.aab`) semnat pentru publicare. APK-ul debug generat aici este doar pentru test.
Pentru AAB va trebui configurată semnarea release (keystore și parole păstrate privat ca GitHub Secrets) și verificată aplicația în Play Console. Nu trimite nimănui parolele, cheia de semnare sau datele contului.

## Identitatea aplicației
- Nume: Cosmarul: Templul Monstrilor
- Application ID: `com.cosmarul.templulmonstrilor.game`

Dacă schimbi Application ID după ce publici, Google Play îl va trata ca pe o aplicație diferită.
